Developer Name: Shaun Thompson, NextGeneration Technologies
Application Version: 1.0
Source Repository: https://github.com/n38803/APD2


CHANGE LOG:
All modifications made with this update are initial and not changes.

CURRENT FEATURE LIST:
- Static Title Textview (to be converted to logo)
- Static Spending Power (to be updated dynamically)
- Non-Functional Navigation Buttons
- Custom Background
- Custom UI Containers for Form & Listview fragments (Expense)
- Custom UI Containers for Form & Listview fragments (Income)
- Non-Functional UI components of Expense & Income Forms
- Un-Populated list view skeleton for Expense & Income list views.

SPECIAL INSTRUCTIONS:
- Please view our Milestone 1 update for full visual experience of UI components.